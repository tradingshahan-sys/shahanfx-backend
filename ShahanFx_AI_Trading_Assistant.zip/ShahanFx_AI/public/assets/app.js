const $ = (s) => document.querySelector(s);

const nav = `
<nav class="navbar"><div class="nav">
<a class="logo" href="/">Shahan<span>Fx</span></a>
<div class="clock">
<b id="krg">KRG: --:--:--</b><b id="lon">London: --:--:--</b><b id="ny">New York: --:--:--</b>
</div>
<div class="links" id="links">
<a href="/">سەرەکی</a><a href="/pages/markets.html">بازاڕەکان</a><a href="/pages/chart.html">چارتی ڕاستەوخۆ</a>
<a href="/pages/ai.html">AI زیرەک</a><a href="/pages/learning.html">فێربوون</a>
<a href="/pages/rules.html">یاساکان</a><a href="/pages/risk.html">ژمێرەر</a><a href="/pages/contact.html">پەیوەندی</a>
</div><div class="menu" onclick="document.getElementById('links').classList.toggle('open')">☰</div>
</div></nav>`;

document.addEventListener("DOMContentLoaded", () => {
  document.body.insertAdjacentHTML("afterbegin", nav);
  const path = location.pathname;
  document.querySelectorAll(".links a").forEach(a => {
    if (a.getAttribute("href") === path || (path === "/" && a.getAttribute("href") === "/")) a.classList.add("active");
  });
  updateClocks(); setInterval(updateClocks,1000);
});

function updateClocks(){
  const f=(tz)=>new Intl.DateTimeFormat("en-GB",{hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false,timeZone:tz}).format(new Date());
  if($("#krg")) $("#krg").textContent="KRG: "+f("Asia/Baghdad");
  if($("#lon")) $("#lon").textContent="London: "+f("Europe/London");
  if($("#ny")) $("#ny").textContent="New York: "+f("America/New_York");
}

function tvChart(symbol="OANDA:XAUUSD", interval="15"){
  return `<div class="tradingview-widget-container" style="height:100%;width:100%">
  <div class="tradingview-widget-container__widget"></div>
  <script src="https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js" async>
  {"autosize":true,"symbol":"${symbol}","interval":"${interval}","timezone":"Asia/Baghdad","theme":"dark","style":"1","locale":"en","enable_publishing":false,"allow_symbol_change":true,"hide_side_toolbar":false,"withdateranges":true,"save_image":false,"support_host":"https://www.tradingview.com"}
  </script></div>`;
}
