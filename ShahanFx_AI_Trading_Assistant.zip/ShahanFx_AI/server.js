const express = require("express");
const path = require("path");
const fs = require("fs");
const dotenv = require("dotenv");
const OpenAI = require("openai");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const publicDir = path.join(__dirname, "public");
const dataDir = path.join(__dirname, "data");
const registrationsFile = path.join(dataDir, "registrations.json");

fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(registrationsFile)) fs.writeFileSync(registrationsFile, "[]");

app.use(express.json({ limit: "12mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(publicDir));

function readRegistrations() {
  try { return JSON.parse(fs.readFileSync(registrationsFile, "utf8")); }
  catch { return []; }
}

function saveRegistration(item) {
  const all = readRegistrations();
  all.push(item);
  fs.writeFileSync(registrationsFile, JSON.stringify(all, null, 2));
}

app.post("/api/course-registration", async (req, res) => {
  const { name, contact } = req.body || {};
  if (!name || !contact) return res.status(400).json({ ok: false, error: "ناو و پەیوەندی پێویستن." });

  const registration = {
    id: Date.now().toString(),
    name: String(name).trim(),
    contact: String(contact).trim(),
    createdAt: new Date().toISOString()
  };

  saveRegistration(registration);

  // Optional Telegram notification.
  if (process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID) {
    try {
      const message =
        `🟨 ShahanFx Course Registration\n\n` +
        `👤 ناو: ${registration.name}\n` +
        `📞 پەیوەندی: ${registration.contact}\n` +
        `🕒 ${registration.createdAt}`;
      await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: process.env.TELEGRAM_CHAT_ID,
          text: message
        })
      });
    } catch (e) {
      console.error("Telegram notification failed:", e.message);
    }
  }

  res.json({ ok: true });
});

app.post("/api/ai/analyze", async (req, res) => {
  const { question, image } = req.body || {};
  if (!image) {
    return res.status(400).json({
      ok: false,
      error: "تکایە وێنەی چارت بنێرە بۆ شیکاری."
    });
  }

  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({
      ok: false,
      error: "OPENAI_API_KEY دانەنراوە. .env دروست بکە و API key ـەکەت تێدا دابنێ."
    });
  }

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const model = process.env.OPENAI_MODEL || "gpt-5.6-luna";

    const prompt = `
You are ShahanFx AI Trading Assistant.
Analyze the supplied trading chart image carefully. Do NOT invent market data that cannot be seen.
Answer in Kurdish Sorani (CKB), keeping technical trading terms such as FVG, Order Block, BOS, CHoCH, Liquidity Sweep, Entry, SL, TP and R:R in English where useful.

Return a structured analysis with:
1. Market direction / structure
2. Candlestick patterns visible
3. Liquidity sweep if visible
4. FVG if visible
5. Order Block if visible
6. BOS / CHoCH if visible
7. Support and resistance
8. Possible BUY scenario with Entry/SL/TP only if the chart supports it
9. Possible SELL scenario with Entry/SL/TP only if the chart supports it
10. Risk/Reward
11. Confidence from 0-100, explicitly described as an estimate, not certainty
12. What would invalidate the setup

Important: Never claim certainty, never fabricate news, and never say the system can guarantee profit.
User question: ${question || "ئەم چارتە بە وردی شیکار بکە."}
`;

    const response = await client.responses.create({
      model,
      input: [{
        role: "user",
        content: [
          { type: "input_text", text: prompt },
          { type: "input_image", image_url: image }
        ]
      }]
    });

    res.json({ ok: true, text: response.output_text || "هیچ وەڵامێک نەگەڕایەوە." });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      ok: false,
      error: "کێشەیەک لە شیکاری AI ڕوویدا.",
      details: process.env.NODE_ENV === "development" ? error.message : undefined
    });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(publicDir, "index.html"));
});

app.listen(PORT, () => {
  console.log(`ShahanFx AI running at http://localhost:${PORT}`);
});
